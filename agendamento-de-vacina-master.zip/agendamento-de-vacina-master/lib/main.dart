import 'package:flutter/material.dart';
import 'package:flutter_application_1/tela_login.dart';

void main() {
  runApp(MaterialApp(
    home: HomePage(),
    theme: ThemeData(primarySwatch: Colors.blue),
  ));
}
