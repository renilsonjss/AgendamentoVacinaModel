# Agendamento de vacinação

Aplicação direcionada para a disciplina de PRMO. 

## Distribuição dos trabalhos:
- TODO [renilsonjs]:
Criar tela inicial;

- TODO [clari34]:
Criar tela de cadastro e a de Informações;

- TODO [dudinha21]:
Criar tela de agendamento;

- TODO [Viviannepio]:
Criar tela de opções;

- TODO [MarianaGuedes]:
Criar tela para consultar o agendamento;


